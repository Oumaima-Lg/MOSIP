#!/bin/sh
mkdir -p /home/mosip/hsm-lib
cp libpkcs11-proxy.so.0 /home/mosip/hsm-lib/
cp libpkcs11-proxy.so.0.1 /home/mosip/hsm-lib/
cp libpkcs11-proxy.so /home/mosip/hsm-lib/
